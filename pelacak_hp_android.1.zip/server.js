
const express = require("express");
const app = express();
const path = require("path");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const lokasi = {};

app.post("/api/lokasi", (req, res) => {
  const { id, lat, lng, waktu } = req.body;
  lokasi[id] = { lat, lng, waktu };
  res.send({ status: "Lokasi diterima" });
});

app.get("/api/lokasi", (req, res) => {
  res.json(lokasi);
});

app.listen(3000, () => console.log("Server aktif di http://localhost:3000"));
